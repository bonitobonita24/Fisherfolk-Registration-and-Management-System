// Next Imports
import Link from 'next/link'

// Third-party Imports
import { ChevronLeftIcon } from 'lucide-react'

// Component Imports
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import ForgotPasswordForm from './forgot-password-form'

// Shared Imports
import BrandLogo from '@/components/shared/brand-logo'

// Config Imports
import themeConfig from '@/configs/themeConfig'

// SVG Imports
import AuthBackgroundShape from '@/assets/svg/auth-background-shape'

const ForgotPasswordView = () => {
  return (
    <div className='relative flex h-auto min-h-screen items-center justify-center overflow-x-hidden px-4 py-10 sm:px-6 lg:px-8'>
      <div className='absolute'>
        <AuthBackgroundShape />
      </div>

      <Card className='z-1 w-full gap-6 py-6 sm:max-w-md'>
        <CardHeader className='gap-6 px-6'>
          <Link href={themeConfig.homePageUrl}>
            <BrandLogo className='gap-3' />
          </Link>

          <div>
            <CardTitle className='mb-1.5 text-2xl font-semibold'>Forgot Password?</CardTitle>
            <CardDescription className='text-base'>
              Enter your email and we&apos;ll send you instructions to reset your password
            </CardDescription>
          </div>
        </CardHeader>

        <CardContent className='space-y-4 px-6'>
          <ForgotPasswordForm />

          <Button variant='ghost' className='group w-full' render={<Link href='/login' />} nativeButton={false}>
            <ChevronLeftIcon className='size-5 transition-transform duration-200 group-hover:-translate-x-0.5' />
            Back to login
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}

export default ForgotPasswordView
